//
//  ViewController.swift
//  MapClient
//
//  Created by tjoeun304 on 2020/03/11.
//  Copyright © 2020 tjoeun304. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    @IBOutlet weak var la_status: UILabel!
    
    @IBOutlet weak var tf_lat: UITextField!
    
    
    @IBOutlet weak var tf_lng: UITextField!
    
    @IBOutlet weak var tf_content: UITextField!
    
    
    @IBAction func btnClick(_ sender: Any) {
        send()
    }
    
    func send(){
       
           //요청 객체 생성
           let url = URL(string: "http://192.168.0.173:9999/regist")
           var urlRequest = URLRequest(url: url!)
        
            //딕셔너리
        
            
        
            
           //post 란 요청의 바다에 실어서 보내야 하므로
           //요청 형식을 구성해야 한다(머리:header , 몸:body)
           //header 정보 구성
           urlRequest.addValue("application/json", forHTTPHeaderField: "Content-type")
           urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
           
           //body 정보 구성
           urlRequest.httpMethod = "post"
           //json 객체 구성
            let json = [
               "lat":tf_lat.text!,
               "lng":tf_lng.text!,
               "content":tf_content.text!
            ]
           do{
               //body에 제이슨 객체 대입 (문자열화 시켜서 == 시리얼화
           urlRequest.httpBody = try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted)
           }catch let error{
               print("json 문자열화 실패",error)
           }
           print(json)
           //구성된 내용을 서버로 전송하되, 동기방식으로 하면 앱이 멈춘다
           //비동기로 전송하자 AsyncTask(안드로이드)
        let urlSession = URLSession.shared
           
        let task = urlSession.dataTask(with: urlRequest, completionHandler: {Data,response,error in
               //로직을 작성할 예정
               //서버로부터 가져올 데이터가 있을 때 작성
               //즉 피드백을 받고 싶을 때
           })
           task.resume()//비동기 요청 수행
        
        
       }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

